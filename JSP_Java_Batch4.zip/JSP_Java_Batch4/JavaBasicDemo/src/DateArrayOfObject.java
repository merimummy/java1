import java.util.*;


public class DateArrayOfObject
{
	public static void main(String [] args)
	
	{
		Scanner sc = new Scanner(System.in);
	    Date allDojs []= new Date[3];
	    int day=0,mon=0,year=0;
	    String name[]=new String[3];
	    
	    for(int i=0;i<allDojs.length;i++)
	    {
	    	System.out.println("Enter UR NAME");
	    	name[i]=sc.next();
	    	
	    	System.out.println("Enter DAY OF JOINING");
	    	day=sc.nextInt();
	    	
	    	
	    	System.out.println("Enter  MONTH OF JOINING");
	    	mon=sc.nextInt();
	    	
	    	
	    	System.out.println("Enter YEAR JOINING");
	    	year=sc.nextInt();
	    	
	    	allDojs[i]=new Date(day,mon,year);
	   
	    }
	    
	    for( int j=0;j<allDojs.length;j++)
	    {
	    System.out.println("DOJ of "+name[j]+" is : "+allDojs[j].dispDate());	
	    	
	    }
	    }
	    
	    
	}
	
	
		
	        
	        
	     
				
	
	

