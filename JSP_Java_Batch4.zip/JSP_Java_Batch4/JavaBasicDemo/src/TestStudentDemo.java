
public class TestStudentDemo {

	public static void main(String[] args)
	
	{
		Student s1=new Student();
		s1.setRollNo(111);
		s1.setStuName("sahil");
		s1.setMark(23);
		
		System.out.println("roll no is: "+s1.getRollNo());
		System.out.println("marks is: "+s1.getMark());
		System.out.println("Student Name is: "+s1.getStuName());
		

	}

}
