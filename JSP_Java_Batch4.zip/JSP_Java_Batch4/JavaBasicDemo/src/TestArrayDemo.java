
public class TestArrayDemo 
{
public static void main (String [] args)
{
	int marks[]=new int[6];
	marks[0]=690;
	marks[1]=590;
	marks[2]=490;
	marks[3]=390;
	marks[4]=290;
	marks[5]=190;
	
	for(int i=0;i<marks.length;i++)
	{
		System.out.println("marks["+i+"] :   "+ marks[i]);
	}
	
	
	
	
	
	////////////////////////////////////////
	int A[]=null;
	A=new int[3];
	A[0]=9;
	A[1]=8;
	A[2]=5;
	
    for(int i=0; i<A.length;i++)
    {
    	System.out.println("A["+i+"] :   "+ A[i]);
    }
    
    
    
    
    //////////////////////////////
	int B[][]=new int[3][2];
	B[0][0]=4;
	B[0][1]=5;
    B[1][0]=6;
    B[1][1]=7;
    B[2][0]=8;
	B[2][1]=9;
	
	for(int i=0;i<B.length;i++)
	{
		for(int j=0; j<B[i].length;j++)
		{
			System.out.print("    "+ B[i][j]);
			}
		System.out.println(" ");
	}
	
	///////////////////////
	
	
	
	
}
}
