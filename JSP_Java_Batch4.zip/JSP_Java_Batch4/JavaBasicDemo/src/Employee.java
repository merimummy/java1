
public class Employee
{
private int empid ;
private String empName;
private float empSal;
private char empGen;

public Employee()
{
	empid=0;
	empName="Unknown";
	empSal=0.0F;
	empGen=' ';
}
public Employee(int empid, String empName, int empSal,char empGen)
{
	//this();// to call parameterized constructor
	//System.out.println("empty constructor called");
	this.empid=empid;
	this.empName=empName;
	this.empSal=empSal;
	this.empGen=empGen;
}
public String Display()
{
return "Employee Id :"+empid+"\nEmployee Name :"+empName+
		"\nEmployee Salary  :"+empSal+"\nEmployee Gender :"+empGen;
}
}
