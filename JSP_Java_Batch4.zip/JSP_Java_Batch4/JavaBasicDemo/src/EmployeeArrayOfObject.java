import java.util.Scanner;


public class EmployeeArrayOfObject 
{

	public static void main(String[] args)
		
	{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of employees");
		int noOfEmployees = sc.nextInt();
		Employee employeeinfo []= new Employee[noOfEmployees];
		int empid=0,empSal; 
		String empName;
		char empGen=' ';
		String temp;
			    
		for(int i=0;i<employeeinfo.length;i++)
		{
			 System.out.println("Enter EMPLOYEEID");
			 empid=sc.nextInt();
			    	
			 System.out.println("Enter EMPLOYEENAME");
			 empName=sc.next();
			    	
			 System.out.println("Enter EMPLOYEESAL");
			 empSal=sc.nextInt();
			    	
			 System.out.println("Enter GENDER");
			 temp=sc.next();
			 empGen=temp.charAt(0);
			    	
			 employeeinfo[i]=new Employee(empid,empName,empSal,empGen);
			   
		}
			    
	    for( int j=0;j<employeeinfo.length;j++)
	    {
			 System.out.println(employeeinfo[j].Display());	
			 System.out.println("****************************");
			    	
	    }
	}
}

