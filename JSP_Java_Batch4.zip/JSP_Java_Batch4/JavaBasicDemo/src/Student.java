
public class Student
{
 private int rollNo;
  private String stuName;
 private int mark;


public int getRollNo()
{
	return rollNo;
}

public String getStuName()
{
	return stuName;
}
public int getMark()
{
	return mark;
}

public void setRollNo(int rollNo)
{
this.rollNo=rollNo;	
}

public void setStuName(String stuName)
{
this.stuName=stuName;	
}


public void setMark (int mark)
{
this.mark=mark;	
}






}




