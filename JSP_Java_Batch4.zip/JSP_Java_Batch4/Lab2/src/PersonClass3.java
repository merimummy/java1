
public class PersonClass3
{
String firstName;
String lastName;
char gender;

	
PersonClass3()
{
	
}
PersonClass3(String firstName, String lastName, char gender)
{
	this.firstName=firstName;
	this.lastName=lastName;
	this.
	
}


	
}
