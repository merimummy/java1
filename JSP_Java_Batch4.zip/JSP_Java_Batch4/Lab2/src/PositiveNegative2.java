import java.util.Scanner;
public class PositiveNegative2 
{
public static void main(String[] args)
{
	Scanner pr =new Scanner(System.in);
	
	System.out.println("enter the number");
	int number=pr.nextInt();
	
	if(number < 0)
	{
	System.out.println("the number is negative ");
	}
	else if(number > 0)
	{
    System.out.println("the  number is postive");
	}
	else
	{
		System.out.println("The number is zero");
	}
}
}
