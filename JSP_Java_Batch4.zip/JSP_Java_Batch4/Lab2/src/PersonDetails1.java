public class PersonDetails1
{
 private String FirstName;
 private String LastName;
 private char gender;
 private int age;
 private double Weight;


public String getFirstName()
{
	return FirstName;
}

public String getLastName()
{
	return LastName;
}

public char getgender()
{
	return gender;
}
public int getage()
{
	return age;
}

public double getWeight()
{
	
return Weight;	
	
}

public void setFirstName(String FirstName)
{
this.FirstName=FirstName;	
}

public void setLastName(String LastName)
{
this.LastName=LastName;	
}

public void setgender(char gender)
{
this.gender=gender;
}

public void setage (int age)
{
this.age=age;	
}

public void setWeight (double Weight)
{
this.Weight=Weight;	
}
}
	



