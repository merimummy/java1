import java.util.*;
public class TestArrayOfSalesManager {

	public static void main(String[] args) 
	{
	Scanner sc=new Scanner(System.in);
   System.out.println("how many employee?");
     int empCount=sc.nextInt();
     Employee empArr[]=new Employee [empCount];
     int eId=0;
     String enm=null;
     int noOfHrs=0;
     int ratePerHr=0;
     float esl=0.0F;
     for(int i=0;i<empArr.length;i++)
     {
    	 System.out.println("enter emp id:");
    	 eId=sc.nextInt();
    	 System.out.println("enter emp name");
    	  enm=sc.next();
    	 System.out.println("enter emp salary");
    	 esl=sc.nextFloat();
    	 System.out.println("what type of Emp "+enm +"Is ?" + "1:Emp\t2:WageEmp\t 3:SalesMgr");
    	 System.out.println("Enter choice");
    	 int choice=sc.nextInt();
    	 switch(choice)
    	 {
    	 case 1:empArr[i]=new Employee(eId,enm,esl);
    	 break;
    	 case 2:System.out.println("enter no of hours u worked");
    	 noOfHrs=sc.nextInt();
    	 System.out.println("enter rate per hours");
    	  ratePerHr=sc.nextInt();
    	 empArr[i]=new WageEmp(eId,enm,esl,noOfHrs,ratePerHr);
    	 break;
    	 default:System.out.println("Enter no of hrs u worked");
    	 noOfHrs=sc.nextInt();
    	 System.out.println("Enter rate per hour");
    	 ratePerHr = sc.nextInt();
    	 System.out.println("Enter sales u have done");
    	 int sale=sc.nextInt();
    	 System.out.println("Enter commision");
    	 float comm=sc.nextFloat();
    	 empArr[i]=new SalesManager(eId,enm,esl,noOfHrs,ratePerHr,sale,comm);
    	 
    	 
    	 
    	 }
    	 
     }
     System.out.println("**********");
     for(int j=0;j<empArr.length;j++)
     {
      if(empArr[j] instanceof SalesManager)
      {
    	  System.out.println("SalesManager :" + empArr[j].dispEmpInfo() + "Monthly Basic Sal: "+ empArr[j].calcEmpAnnualSal());
      }
      else if(empArr[j] instanceof WageEmp)
      {
    	  System.out.println("WageEmp :" + empArr[j].dispEmpInfo() + "Monthly Basic Sal: "+ empArr[j].calcEmpAnnualSal() + 
    			  "Annual Sal: "+ empArr[j].calcEmpAnnualSal());  
      }
      else
      {
    	  
    	  System.out.println("Employee :" + empArr[j].dispEmpInfo() + "Monthly Basic Sal: "+ empArr[j].calcEmpAnnualSal() + 
    			  "Annual Sal: "+ empArr[j].calcEmpAnnualSal());    
      }
      
      
      
      
      
      }
     }
	}


