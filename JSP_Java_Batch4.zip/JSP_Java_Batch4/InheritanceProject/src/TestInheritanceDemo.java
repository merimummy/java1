
public class TestInheritanceDemo {

	public static void main(String[] args) 
	{
    Employee vaishali=new Employee(111,"Vaishali",20000.0F);
    WageEmp babita= new WageEmp(222,"Babita",5000.0F,400,5);
    System.out.println("Emp Info: "+vaishali.dispEmpInfo());
    System.out.println("Emp Monthly Sal: "+vaishali.calcEmpBasicSal());
    System.out.println("Emp Annual sal: "+vaishali.calcEmpAnnualSal());
    
    
    System.out.println("WageEmp Info: "+babita.dispEmpInfo());
    System.out.println("Wage Emp Monthly Sal: "+babita.calcEmpBasicSal());
    System.out.println("Wage Emp Annual sal: "+babita.calcEmpAnnualSal());
    
    
    System.out.println();
    Employee Kritika=new WageEmp(444,"kritika",5000.0F,7,500);
    System.out.println("WageEmp Info: "+Kritika.dispEmpInfo());
    System.out.println("Wage Emp Monthly Sal: "+Kritika.calcEmpBasicSal());
    System.out.println("Wage Emp Annual sal: "+Kritika.calcEmpAnnualSal());
    
    
    
    ///////////////////////////////////////////////////////////////
    Employee e1 =new Employee(444,"Kritika",5000.0F);
    WageEmp e2=new WageEmp(555,"sunita", 5000.0F,3,500);
    Employee e3=new WageEmp(666,"amity",5000.0F,4,500);
    
    
    
    ////////////////Sales manager/////////////////////////////////
    
   
    
		
	}


}
