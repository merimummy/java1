
public class WageEmp extends Employee 
{

	private  int noOfHrs;
	private int ratePerHrs;
	public WageEmp()
	{
	super();
	}
	public WageEmp(int empId, String empName, float empSal, int noOfHrs, int ratePerHrs )
	{
	 super(empId, empName, empSal);
	 
	 this.ratePerHrs=ratePerHrs;
	 this.noOfHrs=noOfHrs;
	}
		
		public float calcEmpBasicSal()
		{
			return super.calcEmpBasicSal() + (ratePerHrs*noOfHrs*22);
		}
		public float calcEmpAnnualSal()
		{
			return calcEmpBasicSal()*12;
					
		}	
	
}
